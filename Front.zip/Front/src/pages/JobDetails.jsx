import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { fetchJobById, applyJob } from "../services/api";

const JobDetails = () => {
  const { id } = useParams();
  const [job, setJob] = useState(null);
  const [resume, setResume] = useState(null);

  useEffect(() => {
    const loadJob = async () => {
      try {
        const res = await fetchJobById(id);
        setJob(res.data);
      } catch (err) {
        alert("Failed to fetch job details");
      }
    };

    loadJob();
  }, [id]);

  const handleApply = async () => {
    if (!resume) {
      alert("Please upload resume");
      return;
    }

    const formData = new FormData();
    formData.append("jobId", id);
    formData.append("resume", resume);

    try {
      const token = localStorage.getItem("token");
      await applyJob(formData, token);
      alert("Applied successfully!");
    } catch (err) {
      alert("Failed to apply");
    }
  };

  if (!job) {
    return (
      <div className="page-bg">
        <div className="glass-card">
          <p className="empty-text">Loading job details...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page-bg">
      <div className="glass-card job-details-card">
        <h2 className="page-title">{job.title}</h2>

        <p className="job-meta">
          {job.company} • {job.location}
        </p>

        <p className="salary big">
          💰 {job.salary}
        </p>

        <div className="job-desc">
          <h4>Job Description</h4>
          <p>{job.description}</p>
        </div>

        <div className="apply-section">
          <input
            type="file"
            className="file-input"
            onChange={(e) => setResume(e.target.files[0])}
          />

          <button
            onClick={handleApply}
            className="dark-btn success"
          >
            Apply Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default JobDetails;
