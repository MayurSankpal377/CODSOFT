import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

const Candidate = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    if (!user || user.role !== "candidate") {
      alert("Access Denied");
      navigate("/");
    }
  }, []);

  return (
    <div className="dashboard-bg">
      <div className="dashboard-glass">
        <h1>Welcome, {user?.name} 👋</h1>
        <p className="dashboard-subtitle">
          Candidate Dashboard
        </p>

        <div className="dashboard-actions">
          <Link to="/jobs">
            <button className="dark-btn">
              View Jobs
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Candidate;