import React, { useEffect, useState } from "react";
import { fetchJobs } from "../services/api";

const EmployerJobs = () => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const fetchMyJobs = async () => {
      try {
        const token = localStorage.getItem("token");
        const user = JSON.parse(localStorage.getItem("user"));

        const res = await fetchJobs(token);

        // ✅ IMPORTANT FIX HERE
        const myJobs = res.data.filter(
          (job) => job.posted_by === user.id
        );

        setJobs(myJobs);
      } catch (err) {
        console.error(err);
        alert("Failed to fetch jobs");
      }
    };

    fetchMyJobs();
  }, []);

  return (
    <div className="dashboard-bg">
      <div className="jobs-glass">
        <h1>My Job Postings</h1>
        <p className="dashboard-subtitle">
          Manage and review your posted jobs
        </p>

        {jobs.length === 0 && (
          <p className="empty-text">
            You haven't posted any jobs yet.
          </p>
        )}

        <div className="jobs-grid">
          {jobs.map((job) => (
            <div key={job.id} className="job-card">
              <h3>{job.title}</h3>
              <p className="job-meta">
                {job.company} • {job.location}
              </p>

              <p><strong>Salary:</strong> {job.salary}</p>
              <p className="job-date">
                Posted on{" "}
                {new Date(job.created_at).toLocaleDateString()}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EmployerJobs;
