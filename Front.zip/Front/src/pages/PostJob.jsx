import React, { useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";
import { createJob } from "../services/api";
const PostJob = () => {
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user")); // ✅ get logged-in user

  const [form, setForm] = useState({
    title: "",
    description: "",
    company: "",
    location: "",
    salary: ""
  });

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const token = localStorage.getItem("token");

      // ✅ VERY IMPORTANT: add postedBy
      const jobData = {
        ...form,
        postedBy: user.id
      };

      await createJob(jobData, token);

      alert("Job posted successfully!");
      navigate("/employer/jobs");
    } catch (err) {
      console.error(err.response || err);
      alert(err.response?.data?.message || "Failed to post job");
    }
  };

  return (
    <div className="page-bg">
      <div className="glass-card large">
        <h2 className="page-title">Post New Job</h2>
        <p className="subtitle">Fill details to publish a job opening</p>

        <form onSubmit={handleSubmit}>
          <input
            className="glass-input"
            name="title"
            placeholder="Job Title"
            value={form.title}
            onChange={handleChange}
            required
          />

          <textarea
            className="glass-input textarea"
            name="description"
            placeholder="Job Description"
            value={form.description}
            onChange={handleChange}
            required
          />

          <input
            className="glass-input"
            name="company"
            placeholder="Company Name"
            value={form.company}
            onChange={handleChange}
            required
          />

          <input
            className="glass-input"
            name="location"
            placeholder="Location"
            value={form.location}
            onChange={handleChange}
            required
          />

          <input
            className="glass-input"
            name="salary"
            placeholder="Salary (e.g. 6 LPA)"
            value={form.salary}
            onChange={handleChange}
            required
          />

          <button className="dark-btn success">
            Publish Job
          </button>
        </form>
      </div>
    </div>
  );
};

export default PostJob;
