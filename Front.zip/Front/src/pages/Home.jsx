import React from "react";
import { useNavigate } from "react-router-dom";

function Home() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  // Candidate portal click
  const handleCandidate = () => {
    if (!user) {
      navigate("/login");
      return;
    }

    if (user.role !== "candidate") {
      alert("You are logged in as Employer");
      return;
    }

    navigate("/candidate");
  };

  // Employer portal click
  const handleEmployer = () => {
    if (!user) {
      navigate("/login");
      return;
    }

    if (user.role !== "employer") {
      alert("You are logged in as Candidate");
      return;
    }

    navigate("/employer");
  };

  return (
    <div className="home-bg">
      <div className="home-glass">
        <h1>
          Welcome{user ? `, ${user.name}` : " to Job Portal"} 👋
        </h1>

        <p className="home-subtitle">
          {user
            ? "Choose your portal to continue"
            : "Login to continue"}
        </p>

        <div className="portal-grid">
          {/* Candidate Portal */}
          <div
            className={`portal-card ${
              user && user.role === "employer" ? "disabled" : ""
            }`}
            onClick={handleCandidate}
          >
            <h3>Candidate Portal</h3>
            <p>Find your dream job</p>
            <button className="dark-btn">Enter</button>
          </div>

          {/* Employer Portal */}
          <div
            className={`portal-card ${
              user && user.role === "candidate" ? "disabled" : ""
            }`}
            onClick={handleEmployer}
          >
            <h3>Employer Portal</h3>
            <p>Post jobs & hire talent</p>
            <button className="dark-btn">Enter</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;