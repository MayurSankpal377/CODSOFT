import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

const Employer = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    if (!user || user.role !== "employer") {
      alert("Access Denied");
      navigate("/");
    }
  }, []);

  return (
    <div className="dashboard-bg">
      <div className="dashboard-glass">
        <h1>Employer Dashboard</h1>
        <p className="dashboard-subtitle">
          Manage your job postings and hiring process
        </p>

        <div className="dashboard-actions">
          <Link to="/employer/jobs">
            <button className="dark-btn">
              View My Jobs
            </button>
          </Link>

          <Link to="/employer/post-job">
            <button className="primary-btn">
              Post New Job
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Employer;