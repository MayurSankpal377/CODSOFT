import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchJobs } from "../services/api";

const Jobs = () => {
  const [jobs, setJobs] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const loadJobs = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await fetchJobs(token);
        setJobs(res.data);
      } catch (err) {
        alert("Failed to fetch jobs");
      }
    };

    loadJobs();
  }, []);

  // 🔍 Search Filter Logic
  const filteredJobs = jobs.filter((job) =>
    job.title.toLowerCase().includes(search.toLowerCase()) ||
    job.company.toLowerCase().includes(search.toLowerCase()) ||
    job.location.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page-bg">
      <div className="glass-card wide">
        <h2 className="page-title">Available Jobs</h2>
        <p className="subtitle">Find the right opportunity for your career</p>

        {/* 🔍 Search Bar */}
        <input
          type="text"
          placeholder="Search by job title, company or location..."
          className="search-input"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        {filteredJobs.length === 0 && (
          <p className="empty-text">No jobs found</p>
        )}

        <div className="jobs-grid">
          {filteredJobs.map((job) => (
            <div key={job.id} className="job-card">
              <h3>{job.title}</h3>

              <p className="job-meta">
                {job.company} • {job.location}
              </p>

              <p className="salary">💰 {job.salary}</p>

              <Link to={`/jobs/${job.id}`}>
                <button className="dark-btn primary">
                  View Details →
                </button>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Jobs;