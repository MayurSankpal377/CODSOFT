import React from "react";
import { Navigate } from "react-router-dom";
import jwt_decode from "jwt-decode";

const ProtectedRoute = ({ children, role }) => {
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user"));

  // 🔴 No token
  if (!token || !user) {
    return <Navigate to="/login" replace />;
  }

  try {
    const decoded = jwt_decode(token);
    const currentTime = Date.now() / 1000;

    // 🔴 Token expired
    if (decoded.exp < currentTime) {
      localStorage.clear();
      return <Navigate to="/login" replace />;
    }

    // 🔴 Role mismatch
    if (role && user.role !== role) {
      return <Navigate to="/" replace />;
    }

  } catch (err) {
    localStorage.clear();
    return <Navigate to="/login" replace />;
  }

  // ✅ All good
  return children;
};

export default ProtectedRoute;