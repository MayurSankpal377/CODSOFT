import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.clear();
    navigate("/login");
  };

  return (
    <nav className="navbar">
      <div className="nav-left">
        <Link to="/home" className="nav-link">Home</Link>

        {!user && (
          <>
            <Link to="/login" className="nav-link">Login</Link>
            <Link to="/register" className="nav-link">Register</Link>
          </>
        )}

        {user && user.role === "candidate" && (
          <Link to="/candidate" className="nav-link">Dashboard</Link>
        )}

        {user && user.role === "employer" && (
          <Link to="/employer" className="nav-link">Dashboard</Link>
        )}
      </div>

      {user && (
        <button onClick={handleLogout} className="logout-btn">
          Logout
        </button>
      )}
    </nav>
  );
};

export default Navbar;
