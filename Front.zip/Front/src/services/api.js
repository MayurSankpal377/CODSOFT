import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api",
});

// Auth
export const registerUser = (userData) =>
  API.post("/auth/register", userData);

export const loginUser = (credentials) =>
  API.post("/auth/login", credentials);

// Jobs
export const fetchJobs = (token) =>
  API.get("/jobs", {
    headers: { Authorization: `Bearer ${token}` },
  });

export const fetchJobById = (id) =>
  API.get(`/jobs/${id}`);

export const createJob = (jobData, token) =>
  API.post("/jobs", jobData, {
    headers: { Authorization: `Bearer ${token}` },
  });

// Applications
export const applyJob = (formData, token) =>
  API.post("/applications", formData, {
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "multipart/form-data",
    },
  });

export default API;
