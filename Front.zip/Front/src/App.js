import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import ErrorBoundary from "./components/ErrorBoundary";

// Pages
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Candidate from "./pages/Candidate";
import Jobs from "./pages/Jobs";
import JobDetails from "./pages/JobDetails";
import Employer from "./pages/Employer";
import EmployerJobs from "./pages/EmployerJobs";
import PostJob from "./pages/PostJob";

function App() {
  return (
    <ErrorBoundary>
      <Navbar />

      <Routes>
        {/* PUBLIC ROUTES */}
        <Route path="/" element={<Home />} />
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* CANDIDATE */}
        <Route
          path="/candidate"
          element={
            <ProtectedRoute role="candidate">
              <Candidate />
            </ProtectedRoute>
          }
        />
        <Route
          path="/jobs"
          element={
            <ProtectedRoute role="candidate">
              <Jobs />
            </ProtectedRoute>
          }
        />
        <Route
          path="/jobs/:id"
          element={
            <ProtectedRoute role="candidate">
              <JobDetails />
            </ProtectedRoute>
          }
        />

        {/* EMPLOYER */}
        <Route
          path="/employer"
          element={
            <ProtectedRoute role="employer">
              <Employer />
            </ProtectedRoute>
          }
        />
        <Route
          path="/employer/jobs"
          element={
            <ProtectedRoute role="employer">
              <EmployerJobs />
            </ProtectedRoute>
          }
        />
        <Route
          path="/employer/post-job"
          element={
            <ProtectedRoute role="employer">
              <PostJob />
            </ProtectedRoute>
          }
        />

        {/* FALLBACK */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </ErrorBoundary>
  );
}

export default App;