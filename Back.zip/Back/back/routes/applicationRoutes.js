// backend/routes/applicationRoutes.js
const express = require("express");
const { createApplication, getApplications } = require("../controllers/applicationController");
const authMiddleware = require("../middleware/authMiddleware");
const upload = require("../middleware/uploads/upload");
const router = express.Router();

router.post(
"/",
authMiddleware,
upload.single("resume"), // 🔥 THIS IS MUST
createApplication
);
router.get("/", authMiddleware, getApplications);

module.exports = router;
