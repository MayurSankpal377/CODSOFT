// backend/routes/jobRoutes.js
const express = require("express");
const { createJob, getJobs, getJob } = require("../controllers/jobController");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/", authMiddleware, createJob);
router.get("/", getJobs);
router.get("/:id", getJob);


module.exports = router;
