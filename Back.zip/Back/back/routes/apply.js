const express = require("express");
const upload = require("./upload"); // your multer setup
const sendSuccessMail = require("./mailer");
const app = express();

// Dummy candidate check function
const isValidCandidate = (email) => {
  // Replace this with your DB check
  const validCandidates = ["mayur@example.com", "krushna@example.com"];
  return validCandidates.includes(email);
};

app.post("/apply", upload.single("resume"), async (req, res) => {
  const { email, name } = req.body;

  if (!req.file) return res.status(400).send("No file uploaded.");

  // Check if candidate exists
  if (!isValidCandidate(email)) {
    return res.status(403).send("You are not a valid candidate.");
  }

  // Send confirmation email
  await sendSuccessMail(email, name);

  res.send({ message: "Application submitted successfully and email sent!", file: req.file.filename });
});

app.listen(3000, () => console.log("Server running on port 3000"));