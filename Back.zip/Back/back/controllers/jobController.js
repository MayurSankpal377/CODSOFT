// backend/controllers/jobController.js
const Job = require("../models/Job");

/**
 * CREATE JOB (Employer only)
 */
exports.createJob = async (req, res) => {
  try {
    // ✅ role check
    if (!req.user || req.user.role !== "employer") {
      return res.status(403).json({ message: "Only employers can post jobs" });
    }

    const { title, description, company, location, salary } = req.body;

    // ✅ basic validation
    if (!title || !description || !company || !location || !salary) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const postedBy = req.user.id;

    const result = await Job.create({
      title,
      description,
      company,
      location,
      salary,
      postedBy,
    });

    return res.status(201).json({
      message: "Job created successfully",
      jobId: result.insertId,
    });
  } catch (err) {
    console.error("Create job error:", err);
    return res.status(500).json({ message: "Failed to create job" });
  }
};

/**
 * GET ALL JOBS (Public)
 */
exports.getJobs = async (req, res) => {
  try {
    const jobs = await Job.getAll();
    return res.json(jobs);
  } catch (err) {
    console.error("Get jobs error:", err);
    return res.status(500).json({ message: "Failed to fetch jobs" });
  }
};

/**
 * GET SINGLE JOB BY ID
 */
exports.getJob = async (req, res) => {
  try {
    const job = await Job.getById(req.params.id);

    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    return res.json(job);
  } catch (err) {
    console.error("Get job error:", err);
    return res.status(500).json({ message: "Failed to fetch job" });
  }
};
