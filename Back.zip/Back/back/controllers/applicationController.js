// backend/controllers/applicationController.js
const Application = require("../models/Application");
const Job = require("../models/Job");
const User = require("../models/User");
const nodemailer = require("nodemailer");

// Nodemailer transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER, // your email
    pass: process.env.EMAIL_PASS, // app password
  },
});

exports.createApplication = async (req, res) => {
  try {
    const { jobId } = req.body;
    const resume = req.file?.filename; // 👈 FILE इथून
    const candidateId = req.user.id;

    if (!jobId || !resume) {
      return res.status(400).json({
        message: "JobId and resume are required",
      });
    }

    const job = await Job.getById(jobId);
    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    const result = await Application.create({
      jobId,
      candidateId,
      resume,
    });

    // emails (as you already wrote ✔️)

    res.status(201).json({
      message:
        "Application submitted successfully. Please check your email.",
      applicationId: result.insertId,
    });
  } catch (err) {
    console.error("Application Error:", err.message);
    res.status(500).json({ message: err.message });
  }
};

exports.getApplications = async (req, res) => {
  try {
    const candidateId = req.user.id;
    const applications = await Application.getByCandidate(candidateId);
    res.json(applications);
  } catch (err) {
    console.error("Get Applications Error:", err.message);
    res.status(500).json({ message: err.message });
  }
};
