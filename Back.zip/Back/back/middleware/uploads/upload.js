const multer = require("multer");
const path = require("path");
const fs = require("fs");

// 1️⃣ Ensure the uploads folder exists
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// 2️⃣ Configure storage with safe filenames
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir); // use absolute path
  },
  filename: (req, file, cb) => {
    // Make filename safe: remove spaces and special characters
    const safeName = file.originalname
      .replace(/\s+/g, "_")          // replace spaces with _
      .replace(/[^a-zA-Z0-9._-]/g, ""); // remove special chars like []
    cb(null, Date.now() + "-" + safeName);
  },
});

// 3️⃣ File filter for allowed types
const fileFilter = (req, file, cb) => {
  const allowedTypes = [
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ];

  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error("Only PDF, DOC, or DOCX files are allowed"), false);
  }
};

// 4️⃣ Export multer upload middleware
const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 }, // optional: max 10MB
});

module.exports = upload;