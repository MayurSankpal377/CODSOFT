// backend/models/Application.js
const dbPromise = require("../config/db");

const Application = {
  create: async ({ jobId, candidateId, resume }) => {
    const db = await dbPromise();
    const [result] = await db.execute(
      "INSERT INTO applications (job_id, candidate_id, resume) VALUES (?, ?, ?)",
      [jobId, candidateId, resume]
    );
    return result;
  },

  getByCandidate: async (candidateId) => {
    const db = await dbPromise();
    const [rows] = await db.execute(
      "SELECT * FROM applications WHERE candidate_id = ?",
      [candidateId]
    );
    return rows;
  },
};

module.exports = Application;
