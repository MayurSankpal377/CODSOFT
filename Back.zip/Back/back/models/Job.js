// backend/models/Job.js
const dbPromise = require("../config/db");

const Job = {
  create: async ({ title, description, company, location, salary, postedBy }) => {
    const db = await dbPromise();
    const [result] = await db.execute(
      "INSERT INTO jobs (title, description, company, location, salary, posted_by) VALUES (?, ?, ?, ?, ?, ?)",
      [title, description, company, location, salary, postedBy]
    );
    return result;
  },

  getAll: async () => {
    const db = await dbPromise();
    const [rows] = await db.execute("SELECT * FROM jobs");
    return rows;
  },

  getById: async (id) => {
    const db = await dbPromise();
    const [rows] = await db.execute("SELECT * FROM jobs WHERE id = ?", [id]);
    return rows[0];
  },
};

module.exports = Job;
