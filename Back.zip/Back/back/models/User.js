// backend/models/User.js
const dbPromise = require("../config/db");
const bcrypt = require("bcryptjs");

const User = {
  create: async ({ name, email, password, role }) => {
    const hashed = await bcrypt.hash(password, 10);
    const db = await dbPromise();
    const [result] = await db.execute(
      "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
      [name, email, hashed, role]
    );
    return { id: result.insertId, name, email, role };
  },

  findByEmail: async (email) => {
    const db = await dbPromise();
    const [rows] = await db.execute("SELECT * FROM users WHERE email = ?", [email]);
    return rows[0];
  },

  findById: async (id) => {
    const db = await dbPromise();
    const [rows] = await db.execute("SELECT * FROM users WHERE id = ?", [id]);
    return rows[0];
  },
};

module.exports = User;
