const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail", // SMTP service
  auth: {
    user: "mayursankpal04@gmail.com",       // your email
    pass: "ktka cclr lvmi iiox",     // app password
  },
});

const sendSuccessMail = async (toEmail, candidateName) => {
  try {
    const info = await transporter.sendMail({
      from: '"Job Portal" <your_email@gmail.com>',
      to: toEmail,
      subject: "Application Successful",
      html: `
        <h3>Hello ${candidateName},</h3>
        <p>Your application has been successfully submitted. Thank you for applying!</p>
        <p>Best regards,<br>Job Portal Team</p>
      `,
    });
    console.log("Email sent: " + info.response);
  } catch (err) {
    console.error("Error sending email:", err);
  }
};

module.exports = sendSuccessMail;